<?php
include('connection.php');
session_start();
if (!isset($_SESSION['email'])) {
    $_SESSION['message'] = "Please log in first!";
    header("Location: ../index.php");
    exit();
};
$id = $_SESSION['id'];
$first_query = "SELECT category_id FROM teacher_categories WHERE teacher_id = $id";
$run_first_query = mysqli_query($connection, $first_query);
$category_id = mysqli_fetch_assoc($run_first_query)['category_id'];

$second_query = "SELECT id FROM tests WHERE category_id = $category_id";
$run_second_query = mysqli_query($connection, $second_query);


$results = [];
while ($test = mysqli_fetch_assoc($run_second_query)) {
    $test_id = $test['id'];
    $third_query = "SELECT * FROM results WHERE test_id = $test_id";
    $run_third_query = mysqli_query($connection, $third_query);
    while ($result = mysqli_fetch_assoc($run_third_query)) {
        $results[] = $result;
    }
}

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <?php include('includes/styleLinks.php'); ?>
</head>

<body>
    <?php include('./includes/sidebar.php'); ?>
    <?php include('./includes/header.php'); ?>

    <main id="main" class="main">
        <div class="pagetitle">
            <h1>Results</h1>
            <nav>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="admin.php">Home</a></li>
                    <li class="breadcrumb-item">Tables</li>
                    <li class="breadcrumb-item active">Data</li>
                </ol>
            </nav>
        </div><!-- End Page Title -->

        <section class="section">
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-body">
                            <h5 class="card-title">Result table</h5>
                            <?php
                            if (isset($_SESSION['message'])) { ?>
                                <div class="alert alert-success alert-dismissible fade show" role="alert">
                                    <?php echo $_SESSION['message']; ?>!
                                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                                </div>
                            <?php
                                unset($_SESSION['message']);
                            }
                            ?>
                            <table class="table datatable">
                                <thead>
                                    <tr>
                                        <th>No.</th>
                                        <th>Name</th>
                                        <th>Test Name</th>
                                        <th>Total Marks</th>
                                        <th>Obtained Marks</th>
                                        <th>Add Subjective Marks</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    $count = 1;
                                    foreach ($results as $arr) {
                                        $result_id = $arr['id'];
                                        $user_id = $arr['user_id'];
                                        $query_user = "SELECT name FROM users WHERE id = $user_id";
                                        $run_user = mysqli_query($connection, $query_user);
                                        if ($run_user) {
                                            $user_name = mysqli_fetch_assoc($run_user)['name'];
                                        } else {
                                            $user_name = "Unknown User";
                                        }

                                        $test_id = $arr['test_id'];
                                        $test_query = "SELECT name FROM tests WHERE id = $test_id";
                                        $run_test = mysqli_query($connection, $test_query);
                                        if ($run_test) {
                                            $test_name = mysqli_fetch_assoc($run_test)['name'];
                                        } else {
                                            $test_name = "Unknown Test";
                                        }

                                        echo "<tr>";
                                        echo "<td>" . $count . "</td>";
                                        echo "<td>" . $user_name . "</td>";
                                        echo "<td>" . $test_name . "</td>";
                                        echo "<td>" . (($arr['correct_Answers'] + $arr['wrong_answers']) * 1 + $arr['total_subjective_marks']) . "</td>";
                                        echo "<td>" . ($arr['correct_Answers'] * 1 + $arr['total_obtained_marks']) . "</td>";
                                    ?>
                                        <td>
                                            <?php if ($arr['total_subjective_marks'] > 0) { ?>
                                                <a href="EditSubjective.php?id=<?php echo ($arr['id']) ?>" class="btn btn-primary mx-1"><i class="bi bi-pencil-square"></i> Edit</a>
                                            <?php } else { ?>
                                                <a href="AddSubjective.php?id=<?php echo ($arr['id']) ?>" class="btn btn-warning mx-1"><i class="bi bi-bookmark-plus"></i> Add</a>
                                            <?php } ?>
                                        </td>
                                    <?php
                                        echo "</tr>";
                                        $count++;
                                    }
                                    ?>
                                </tbody>
                            </table>
                            <!-- End Table with stripped rows -->
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </main><!-- End #main -->
    <?php
    require('./includes/footer.php')
    ?>
</body>

</html>