<?php
session_start();
if (!isset($_SESSION['email'])) {
    $_SESSION['message'] = "Please log in first!";
    header("Location: ../index.php");
    exit();
};
include('connection.php');


$id = $_SESSION['id'];
$query = "SELECT category_id FROM teacher_categories WHERE teacher_id = $id";
$teacher_categories = mysqli_query($connection, $query);
$result = mysqli_fetch_array($teacher_categories);
$category_id = $result['category_id'];

$secondquery = "SELECT * FROM categories WHERE id = $category_id";
$result2 = mysqli_query($connection, $secondquery);
$category = mysqli_fetch_array($result2);

if (isset($_POST['submit'])) {
    $name = $_POST['name'];
    $mainquery = "SELECT * FROM tests WHERE name = '$name'";
    $runmainquery = mysqli_query($connection, $mainquery);
    if (mysqli_num_rows($runmainquery) > 0) {
        $_SESSION['not-added'] = "Test name already exists!";
        header('location: addTest.php');
        exit();
    }
    $category = $_POST['test_type'];
    $teacher_id = $_SESSION['id'];
    $query = "INSERT INTO tests (user_id,category_id, name) VALUES ('$teacher_id','$category', '$name')";
    mysqli_query($connection, $query);
    $test = mysqli_fetch_assoc(mysqli_query($connection, "SELECT * FROM tests WHERE name = '$name'"));


    unset($_SESSION['question-added']);
    unset($_SESSION['not-added']);
    $count = $_POST['count'];
    for ($i = 1; $i <= $count; $i++) {
        $id = $test['id'];
        $question = $_POST['question_' . $i];
        $option1 = $_POST['option1_' . $i];
        $option2 = $_POST['option2_' . $i];
        $option3 = $_POST['option3_' . $i];
        $option4 = $_POST['option4_' . $i];
        $correct = $_POST['correct_' . $i];

        $query = "INSERT INTO questions (test_id,question , option1 , option2 , option3 , option4 ,answer) VALUES ($id,'$question','$option1', '$option2', '$option3', '$option4', '$correct')";
        $runquery =  mysqli_query($connection, $query);
    }
    if ($runquery) {
        $_SESSION['question-added'] = "Your test is created successfully!";
    } else {
        $_SESSION['not-added'] = "Failed to add Your test!";
    }
    header('location: allTests.php');
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <?php
    include('./includes/styleLinks.php')
    ?>
</head>

<body>
    <?php
    include('./includes/header.php')
    ?>
    <?php
    include('./includes/sidebar.php')
    ?>
    <main id="main" class="main">
        <div class="pagetitle">
            <h1>Add Test</h1>
            <nav>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="user.php">Home</a></li>
                    <li class="breadcrumb-item active">Dashboard</li>
                </ol>
            </nav>
        </div>
        <div class="container mt-5">
            <div class="row justify-content-center">
                <div class="col-md-8">
                    <div class="card">
                        <div class="card-body">
                            <h5 class="card-title" style="color: #012970;">Add Test</h5>
                            <form action="addtest.php" method="POST">
                                <div class="mb-3">
                                    <label for="question" class="form-label" style="color: #012970;">Test Name:</label>
                                    <input type="text" class="form-control" id="question" name="name" required>
                                    <?php
                                    if (isset($_SESSION['not-added'])) {
                                    ?>
                                        <div class="alert alert-success alert-dismissible fade show" role="alert">
                                            <i class="bi bi-check-circle me-1"></i>
                                            <?php echo $_SESSION['not-added']; ?>
                                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                                        </div>
                                    <?php
                                        unset($_SESSION['not-added']);
                                    }
                                    ?>
                                </div>
                                <div class="mb-3">
                                    <label for="testType" class="form-label" style="color: #012970;">Select Test Type:</label>
                                    <select class="form-select" id="testType" name="test_type" required>
                                        <?php
                                        echo "<option value='" . $category['id'] . "'>" . $category['name'] . "</option>";
                                        ?>
                                    </select>
                                </div>
                                <hr>

                                <div class="mb-3">
                                    <label for="question" class="form-label" style="color: #012970;">Question 1:</label>
                                    <input type="text" class="form-control" id="question" name="question_1" required>
                                </div>
                                <div class="mb-3">
                                    <label for="option1" class="form-label" style="color: #012970;">Option 1:</label>
                                    <input type="text" class="form-control" id="option1" name="option1_1" required>
                                    <div class="form-check mt-2">
                                        <input type="radio" class="form-check-input" id="correct1" name="correct_1" value="option1">
                                        <label class="form-check-label" for="correct1" style="color: #012970;">Correct Answer</label>
                                    </div>
                                </div>
                                <div class="mb-3">
                                    <label for="option2" class="form-label" style="color: #012970;">Option 2:</label>
                                    <input type="text" class="form-control" id="option2" name="option2_1" required>
                                    <div class="form-check mt-2">
                                        <input type="radio" class="form-check-input" id="correct2" name="correct_1" value="option2">
                                        <label class="form-check-label" for="correct2" style="color: #012970;">Correct Answer</label>
                                    </div>
                                </div>
                                <div class="mb-3">
                                    <label for="option3" class="form-label" style="color: #012970;">Option 3:</label>
                                    <input type="text" class="form-control" id="option3" name="option3_1" required>
                                    <div class="form-check mt-2">
                                        <input type="radio" class="form-check-input" id="correct3" name="correct_1" value="option3">
                                        <label class="form-check-label" for="correct3" style="color: #012970;">Correct Answer</label>
                                    </div>
                                </div>
                                <div class="mb-3">
                                    <label for="option4" class="form-label" style="color: #012970;">Option 4:</label>
                                    <input type="text" class="form-control" id="option4" name="option4_1" required>
                                    <div class="form-check mt-2">
                                        <input type="radio" class="form-check-input" id="correct4" name="correct_1" value="option4">
                                        <label class="form-check-label" for="correct4" style="color: #012970;">Correct Answer</label>
                                    </div>
                                </div>
                                <div id="form-container"></div>
                                <button id="formbutton" name="more" class="btn btn-primary" style="background-color: #012970; border: none;">Add More Question</button>
                                <input type="hidden" name="count" id="count" value="1">
                                <input name="submit" type="submit" value="Submit" class="btn btn-primary" style="background-color: #012970; border: none;">
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php
        require('./includes/footer.php')
        ?>
        <script>
            var count = 1;
            document.getElementById("formbutton").addEventListener("click", function() {
                count++;
                let newDiv = document.createElement("div");
                newDiv.innerHTML = `
            <hr>
    <div class="mb-3">
        <label for="question" class="form-label" style="color: #012970;">Question ` + count + `:</label>
        <input type="text" class="form-control" id="question" name="question_` + count + `" required>
    </div>
    <div class="mb-3">
        <label for="option1" class="form-label" style="color: #012970;">Option 1:</label>
        <input type="text" class="form-control" id="option1" name="option1_` + count + `" required>
        <div class="form-check mt-2">
            <input type="radio" class="form-check-input" id="correct1" name="correct_` + count + `" value="option1">
            <label class="form-check-label" for="correct1" style="color: #012970;">Correct Answer</label>
        </div>
    </div>
    <div class="mb-3">
        <label for="option2" class="form-label" style="color: #012970;">Option 2:</label>
        <input type="text" class="form-control" id="option2" name="option2_` + count + `" required>
        <div class="form-check mt-2">
            <input type="radio" class="form-check-input" id="correct2" name="correct_` + count + `" value="option2">
            <label class="form-check-label" for="correct2" style="color: #012970;">Correct Answer</label>
        </div>
    </div>
    <div class="mb-3">
        <label for="option3" class="form-label" style="color: #012970;">Option 3:</label>
        <input type="text" class="form-control" id="option3" name="option3_` + count + `" required>
        <div class="form-check mt-2">
            <input type="radio" class="form-check-input" id="correct3" name="correct_` + count + `" value="option3">
            <label class="form-check-label" for="correct3" style="color: #012970;">Correct Answer</label>
        </div>
    </div>
    <div class="mb-3">
        <label for="option4" class="form-label" style="color: #012970;">Option 4:</label>
        <input type="text" class="form-control" id="option4" name="option4_` + count + `" required>
        <div class="form-check mt-2">
            <input type="radio" class="form-check-input" id="correct4" name="correct_` + count + `" value="option4">
            <label class="form-check-label" for="correct4" style="color: #012970;">Correct Answer</label>
        </div>
    </div>
            `;
                document.getElementById("count").value = count;
                document.getElementById("form-container").appendChild(newDiv);
            });
        </script>
</body>

</html>