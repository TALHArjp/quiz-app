<?php
session_start();
if (!isset($_SESSION['email'])) {
    $_SESSION['message'] = "Please log in first!";
    header("Location: ../index.php");
    exit();
};
include('connection.php');

$id = $_GET['id'];

$query = "DELETE FROM users WHERE id = $id";
$runquery = mysqli_query($connection, $query);
if ($runquery) {
    $_SESSION['Data-Deleted'] = "Data is deleted successfully";
    header('location: allTeachers.php');
    exit();
}
