<?php
session_start();
if (!isset($_SESSION['email'])) {
    $_SESSION['message'] = "Please log in first!";
    header("Location: ../index.php");
    exit();
};
include('connection.php');
if (isset($_POST['submit'])) {
    $name = $_POST['name'];
    $username = $_POST['username'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $designation = 'Null';
    $role = "user";
    $query = "INSERT INTO users (name,username,role,designation,email,password) VALUES ('$name','$username','$role','$designation','$email','$password')";
    $result = mysqli_query($connection, $query);
    header('location: allstudents.php');
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <?php
    include('./includes/styleLinks.php')
    ?>
</head>

<body>
    <?php
    include('./includes/header.php')
    ?>
    <?php
    include('./includes/sidebar.php')
    ?>
    <main id="main" class="main">
        <div class="pagetitle">
            <h1>Add Student</h1>
            <nav>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="user.php">Home</a></li>
                    <li class="breadcrumb-item active">Dashboard</li>
                </ol>
            </nav>
        </div>
        <div class="container mt-5">
            <div class="row justify-content-center">
                <div class="col-md-8">
                    <div class="card">
                        <div class="card-body">
                            <h5 class="card-title" style="color: #012970;">Add New Student</h5>
                            <form action="#" method="POST">
                                <div class="mb-3">
                                    <label for="student" class="form-label" style="color: #012970;">Student Name:</label>
                                    <input type="text" class="form-control" id="student" name="name" required>
                                </div>
                                <div class="mb-3">
                                    <label for="username" class="form-label" style="color: #012970;">username:</label>
                                    <input type="text" class="form-control" id="username" name="username" required>
                                </div>
                                <div class="mb-3">
                                    <label for="email" class="form-label" style="color: #012970;">Email:</label>
                                    <input type="email" class="form-control" id="email" name="email" required>
                                </div>
                                <div class="mb-3">
                                    <label for="password" class="form-label" style="color: #012970;">Password:</label>
                                    <input type="password" class="form-control" id="password" name="password" required>
                                </div>
                                <input name="submit" type="submit" value="Add New" class="btn btn-primary" style="background-color: #012970; border: none;">
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php
        require('./includes/footer.php')
        ?>
</body>

</html>