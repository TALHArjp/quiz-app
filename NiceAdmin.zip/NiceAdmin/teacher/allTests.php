<?php
session_start();
if (!isset($_SESSION['email'])) {
    $_SESSION['message'] = "Please log in first!";
    header("Location: ../index.php");
    exit();
};
include('connection.php');

$id = $_SESSION['id'];
$query = "SELECT category_id FROM teacher_categories WHERE teacher_id = $id";
$runquerry = mysqli_query($connection, $query);
$result = mysqli_fetch_assoc($runquerry);
$category_id = $result['category_id'];

$query = "SELECT * FROM categories WHERE id = $category_id";
$runquerry = mysqli_query($connection, $query);
$category = mysqli_fetch_assoc($runquerry);
$category_name = $category['name'];

$query = "SELECT * FROM tests WHERE category_id = $category_id";
$runquerry = mysqli_query($connection, $query);

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <?php
    include('./includes/styleLinks.php');
    ?>
    <!-- =======================================================
  * Template Name: NiceAdmin
  * Template URL: https://bootstrapmade.com/nice-admin-bootstrap-admin-html-template/
  * Updated: Apr 20 2024 with Bootstrap v5.3.3
  * Author: BootstrapMade.com
  * License: https://bootstrapmade.com/license/
  ======================================================== -->
</head>

<body>

    <?php
    include('./includes/header.php')
    ?>

    <?php
    include('./includes/sidebar.php')
    ?>

    <main id="main" class="main">

        <div class="pagetitle">
            <h1>Test Table</h1>
            <nav>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="admin.php">Home</a></li>
                    <li class="breadcrumb-item">Tables</li>
                    <li class="breadcrumb-item active">Data</li>
                </ol>
            </nav>
        </div><!-- End Page Title -->

        <section class="section">
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-body">
                            <h5 class="card-title">Test Table</h5>
                            <?php
                            if (isset($_SESSION['Test-updated'])) { ?>
                                <div class="alert alert-success alert-dismissible fade show" role="alert">
                                    <?php echo $_SESSION['Test-updated']; ?>!
                                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                                </div>
                            <?php
                                unset($_SESSION['Test-updated']);
                            }
                            ?>
                            <?php
                            if (isset($_SESSION['question-added'])) { ?>
                                <div class="alert alert-success alert-dismissible fade show" role="alert">
                                    <?php echo $_SESSION['question-added']; ?>!
                                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                                </div>
                            <?php
                                unset($_SESSION['question-added']);
                            }
                            ?>
                            <?php
                            if (isset($_SESSION['Data-Deleted'])) { ?>
                                <div class="alert alert-success alert-dismissible fade show" role="alert">
                                    <?php echo $_SESSION['Data-Deleted']; ?>!
                                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                                </div>
                            <?php
                                unset($_SESSION['Data-Deleted']);
                            }
                            ?>
                            <table class="table datatable">
                                <thead>
                                    <tr>
                                        <th>No.</th>
                                        <th>Name</th>
                                        <th>Category</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    $counter = 1;

                                    while ($arr = mysqli_fetch_array($runquerry)) {
                                        echo "<tr>";
                                        echo "<td>" . $counter . "</td>";
                                        echo "<td>" . $arr['name'] . "</td>";
                                        echo "<td>" . $category_name . "</td>";
                                    ?>
                                        <td>
                                            <?php
                                            if ($arr['user_id'] == $id) { ?>
                                                <a href="EditTest.php?id=<?php echo ($arr['id']) ?>" class="btn btn-warning mx-1"><i class="ri-edit-line"></i></a>
                                                <a onclick="confirmDelete(<?php echo ($arr['id']) ?>)" class="btn btn-danger mx-1"><i class="bi bi-trash"></i></a>
                                            <?php
                                            }
                                            ?>
                                        </td>
                                    <?php
                                        echo "</tr>";
                                        $counter++;
                                    }
                                    ?>
                                </tbody>

                            </table>
                            <!-- End Table with stripped rows -->

                        </div>
                    </div>

                </div>
            </div>
        </section>
        <?php
        require('./includes/footer.php')
        ?>
    </main><!-- End #main -->
    <script>
        function confirmDelete(event) {
            // event.preventDefault(); 
            const userConfirmed = confirm("Are you sure you want to delete this item?");
            if (userConfirmed) {
                window.location.href = "DeleteTest.php?id=" + encodeURIComponent(event);
            }
        }
    </script>
</body>

</html>