<?php
session_start();
if (!isset($_SESSION['email'])) {
    $_SESSION['message'] = "Please log in first!";
    header("Location: ../index.php");
    exit();
}
include('connection.php');
$id = $_SESSION['id'];
$query = "SELECT category_id FROM teacher_categories WHERE teacher_id = '$id'";
$runquery = mysqli_query($connection, $query);
$result = mysqli_fetch_assoc($runquery);
$category_id = $result['category_id'];
$tests_query = "SELECT COUNT(*) AS totaltests FROM tests WHERE category_id = '$category_id'";
$query_result = mysqli_query($connection, $tests_query);
$totaltests = 0;
if ($row = mysqli_fetch_array($query_result)) {
    $totaltests = $row['totaltests'];
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
<?php
require('./includes/styleLinks.php')
?>
</head>

<body>
    <?php
    require('./includes/header.php')
    ?> 
    <?php
    require('./includes/sidebar.php')
    ?> 
  <main id="main" class="main">
    <div class="pagetitle">
      <h1>Dashboard</h1>
      <nav>
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="teacher.php">Home</a></li>
          <li class="breadcrumb-item active">Dashboard</li>
        </ol>
      </nav>
    </div><!-- End Page Title -->
 <section class="section dashboard">
  <div class="row">
    <!-- Test Cards Row -->
    <div class="col-lg-12">
      <div class="row">
        <!-- Python Test Card -->
        <div class="col-xxl-3 col-md-6">
          <a href="allTests.php" class="card info-card test-card">
            <div class="card-body">
              <h5 class="card-title">Tests</h5>
              <div class="d-flex align-items-center">
                <div class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                  <?php echo $totaltests?>
                </div>
              </div>
            </div>
          </a>
        </div><!-- End Python Test Card -->
      </div>
    </div><!-- End Test Cards Row -->
  </div>
 </section>
</main><!-- End #main -->

    <?php
    require('./includes/footer.php') 
    ?>
</body>

</html>