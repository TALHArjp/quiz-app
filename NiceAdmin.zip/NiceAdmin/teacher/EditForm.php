<?php
session_start();
if (!isset($_SESSION['email'])) {
    $_SESSION['message'] = "Please log in first!";
    header("Location: ../index.php");
    exit();
};
include('connection.php');

//User ko view kiya ja rha ha...
$id = $_GET['id'];
$sql = "SELECT * FROM users WHERE id = '$id'";
$sql_run = mysqli_query($connection, $sql);
$data = mysqli_fetch_array($sql_run);
$teacher_id = $data['id'];

//User ko update kiya ja rha ha ...
if (isset($_POST['Update'])) {
    $name = $_POST['name'];
    $username = $_POST['username'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $role = "teacher";

    $category = $_POST['category_id'];
    $sql_update = "UPDATE users SET name='$name', username='$username', email='$email', password='$password', role='$role' WHERE id='$id'";
    $run_querry = mysqli_query($connection, $sql_update);


    $sqlSecondUpdate = "UPDATE teacher_categories SET category_id='$category' WHERE teacher_id='$teacher_id'";
    $run_second_querry = mysqli_query($connection, $sqlSecondUpdate);
    if ($run_querry) {
        $_SESSION['Updated-successfully'] = 'Updated successfully';
    } else {
        $_SESSION['error-updating'] = 'Error updating';
    }
    header("location: allTeachers.php");
    exit();
}
// categories nu fetch kita ja rya wa
$query = "SELECT * FROM categories";
$runquerry = mysqli_query($connection, $query);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <?php
    include('./includes/styleLinks.php')
    ?>
</head>

<body>
    <?php
    include('./includes/header.php')
    ?>
    <?php
    include('./includes/sidebar.php')
    ?>
    <main id="main" class="main">
        <div class="pagetitle">
            <h1>Update Teacher Form</h1>
            <nav>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="user.php">Home</a></li>
                    <li class="breadcrumb-item active">Dashboard</li>
                </ol>
            </nav>
        </div>
        <div class="container mt-5">
            <div class="row justify-content-center">
                <div class="col-md-8">
                    <div class="card">
                        <div class="card-body">
                            <h5 class="card-title" style="color: #012970;">Update Teacher</h5>
                            <form action="#" method="POST">
                                <div class="mb-3">
                                    <label for="Teacher" class="form-label" style="color: #012970;">Teacher Name:</label>
                                    <input type="text" class="form-control" id="Teacher" name="name" value="<?php echo ($data['name']) ?>" required>
                                </div>
                                <div class="mb-3">
                                    <label for="Teacher" class="form-label" style="color: #012970;">UserName:</label>
                                    <input type="text" class="form-control" id="Teacher" name="username" value="<?php echo ($data['username']) ?>" required>
                                </div>
                                <div class="mb-3">
                                    <label for="email" class="form-label" style="color: #012970;">Email:</label>
                                    <input type="email" class="form-control" id="email" name="email" value="<?php echo ($data['email']) ?>" required>
                                </div>
                                <div class="mb-3">
                                    <label for="password" class="form-label" style="color: #012970;">Password:</label>
                                    <div class="input-group">
                                        <input type="password" name="password" value="<?php echo ($data['password']) ?>" class="form-control" id="yourPassword" required>
                                        <button class="btn btn-outline-secondary" type="button" id="togglePassword">
                                            <i class="bi bi-eye-slash" id="toggleIcon"></i>
                                        </button>
                                    </div>
                                </div>
                                <div class="mb-3">
                                    <label for="testType" class="form-label" style="color: #012970;">Select Category:</label>
                                    <select name="category_id" class="form-select" required>
                                        <?php while ($row = mysqli_fetch_assoc($runquerry)) { ?>
                                            <option value="<?php echo $row['id'] ?>" <?php echo ($data['name'] == $row['id']) ? 'selected' : '' ?>><?php echo $row['name'] ?></option>
                                        <?php } ?>
                                    </select>
                                </div>
                                <input name="Update" type="submit" value="Update" class="btn btn-primary" style="background-color: #012970; border: none;">
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php
        require('./includes/footer.php')
        ?>
        <script>
            document.addEventListener('DOMContentLoaded', function() {
                const togglePassword = document.getElementById('togglePassword');
                const password = document.getElementById('yourPassword');
                const toggleIcon = document.getElementById('toggleIcon');

                togglePassword.addEventListener('click', function() {
                    const type = password.getAttribute('type') === 'password' ? 'text' : 'password';
                    password.setAttribute('type', type);
                    toggleIcon.classList.toggle('bi-eye');
                    toggleIcon.classList.toggle('bi-eye-slash');
                });
            });
        </script>
</body>

</html>