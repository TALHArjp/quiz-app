<?php
include('connection.php');
session_start();
if (!isset($_SESSION['email'])) {
    $_SESSION['message'] = "Please log in first!";
    header("Location: ../index.php");
    exit();
}
$id = $_GET['id'];
$query = "SELECT * FROM results WHERE id = $id";
$result = mysqli_query($connection, $query);
if ($result) {
    $record = mysqli_fetch_assoc($result);
}

if (isset($_POST['Update'])) {
    $total_marks = $_POST['total-marks'];
    $obtained_marks = $_POST['obtained-marks'];
    $query = "UPDATE results SET total_subjective_marks = '$total_marks', total_obtained_marks = '$obtained_marks' WHERE id = $id";
    mysqli_query($connection, $query);
    $_SESSION['message'] = "Data updated successfully!";
    header('location: StudentsResult.php');
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <?php
    include('./includes/styleLinks.php')
    ?>
</head>

<body>
    <?php
    include('./includes/header.php')
    ?>
    <?php
    include('./includes/sidebar.php')
    ?>
    <main id="main" class="main">
        <div class="pagetitle">
            <h1>Edit Subjective Marks</h1>
            <nav>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="user.php">Home</a></li>
                    <li class="breadcrumb-item active">Dashboard</li>
                </ol>
            </nav>
        </div>
        <div class="container mt-5">
            <div class="row justify-content-center">
                <div class="col-md-8">
                    <div class="card">
                        <div class="card-body">
                            <h5 class="card-title" style="color: #012970;">Add Subjective Marks</h5>
                            <form action="#" method="POST">
                                <div class="mb-3">
                                    <?php
                                    if (isset($_SESSION['error'])) {
                                    ?>
                                        <div class="alert alert-success alert-dismissible fade show" role="alert">
                                            <i class="bi bi-check-circle me-1"></i>
                                            <?php echo $_SESSION['error']; ?>
                                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                                        </div>
                                    <?php
                                        unset($_SESSION['error']);
                                    }
                                    ?>
                                    <label for="total-marks" class="form-label" style="color: #012970;">Total Marks:</label>
                                    <input type="number" value="<?php echo $record['total_subjective_marks'] ?>" class="form-control" id="total-marks" name="total-marks" required>
                                </div>
                                <div class="mb-3">
                                    <label for="obtained-marks" class="form-label" style="color: #012970;">Obtained Marks:</label>
                                    <input type="number" value="<?php echo $record['total_obtained_marks'] ?>" class="form-control" id="obtained-marks" name="obtained-marks" required>
                                </div>
                                <input name="Update" type="submit" value="Update Marks" class="btn btn-primary" style="background-color: #012970; border: none;">
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php
        require('./includes/footer.php')
        ?>
</body>

</html>