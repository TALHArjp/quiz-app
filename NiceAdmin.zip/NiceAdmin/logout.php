<?php
session_start();
session_unset();
session_destroy();

session_start();
	$_SESSION['message'] = 'Logout Successfully!';
	header('Location:index.php');
?>