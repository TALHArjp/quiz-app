<?php
session_start();
if (!isset($_SESSION['email'])) {
  $_SESSION['message'] = "Please log in first!";
  header("Location: ../index.php");
  exit();
};
include('connection.php');
$students = "SELECT COUNT(*) AS totalusers FROM users WHERE role = 'user'";
$teachers = "SELECT COUNT(*) AS totalteachers FROM users WHERE role = 'teacher'";
$tests = "SELECT COUNT(*) AS totaltests FROM tests ";
$categories = "SELECT COUNT(*) AS totalcategories FROM categories";

$runquery = mysqli_query($connection, $students);
$secondquery = mysqli_query($connection, $teachers);
$thirdquery = mysqli_query($connection, $tests);
$forthquery = mysqli_query($connection, $categories);

$totaluser= 0;
$totalteachers= 0;
$totaltests = 0;
$totalcategories = 0;

if ($row = mysqli_fetch_array($runquery)) {
  $totaluser = $row['totalusers'];
}
if ($row = mysqli_fetch_array($secondquery)) {
  $totalteachers = $row['totalteachers'];
}

if ($row = mysqli_fetch_array($thirdquery)) {
  $totaltests = $row['totaltests'];
}

if ($row = mysqli_fetch_array($forthquery)) {
  $totalcategories = $row['totalcategories'];
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
  <?php
    include('./includes/styleLinks.php')
 ?>
</head>

<body>
    <?php
    require('./includes/header.php')
    ?> 
    <?php
    require('./includes/sidebar.php')
    ?> 
  <main id="main" class="main">
    <div class="pagetitle">
      <h1>Dashboard</h1>
      <nav>
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="admin.php">Home</a></li>
          <li class="breadcrumb-item active">Dashboard</li>
        </ol>
      </nav>
    </div><!-- End Page Title -->
 <section class="section dashboard">
  <div class="row">
    <!-- Test Cards Row -->
    <div class="col-lg-12">
      <div class="row">

     <!-- JavaScript Test Card -->
     <div class="col-xxl-3 col-md-6">
          <a href="allstudents.php" class="card info-card test-card">
            <div class="card-body">
              <h5 class="card-title">Students</h5>
              <div class="d-flex align-items-center">
                <div class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                  <h2><?php echo $totaluser?></h2>
                </div>
              </div>
            </div>
          </a>
        </div><!-- End JavaScript Test Card -->

        <!-- PHP Test Card -->
        <div class="col-xxl-3 col-md-6">
          <a href="allTeachers.php" class="card info-card test-card">
            <div class="card-body">
              <h5 class="card-title">Teachers</h5>
              <div class="d-flex align-items-center">
                <div class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                  <h2><?php echo $totalteachers?></h2>
                </div>
              </div>
            </div>
          </a>
        </div><!-- End PHP Test Card -->

        <!-- Python Test Card -->
        <div class="col-xxl-3 col-md-6">
          <a href="allTests.php" class="card info-card test-card">
            <div class="card-body">
              <h5 class="card-title">Tests</h5>
              <div class="d-flex align-items-center">
                <div class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                  <?php echo $totaltests?>
                </div>
              </div>
            </div>
          </a>
        </div><!-- End Python Test Card -->

        <!-- C++ Test Card -->
        <div class="col-xxl-3 col-md-6">
          <a href="categories.php" class="card info-card test-card">
            <div class="card-body">
              <h5 class="card-title">Categories</h5>
              <div class="d-flex align-items-center">
                <div class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                  <?php echo $totalcategories?>
                </div>
              </div>
            </div>
          </a>
        </div><!-- End C++ Test Card -->
      </div>
    </div><!-- End Test Cards Row -->
  </div>
 </section>
</main><!-- End #main -->
    <?php
    require('./includes/footer.php') 
    ?>
</body>

</html>