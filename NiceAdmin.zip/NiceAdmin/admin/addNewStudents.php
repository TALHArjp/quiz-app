<?php
session_start();
if (!isset($_SESSION['email'])) {
    $_SESSION['message'] = "Please log in first!";
    header("Location: ../index.php");
    exit();
}
include('connection.php');

if (isset($_POST['submit'])) {
    $name = $_POST['name'];
    $username = $_POST['username'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $role = "user";
    $check_username = "SELECT * FROM users WHERE username = '$username'";
    $runquery = mysqli_query($connection, $check_username);
    if (mysqli_num_rows($runquery) > 0) {
        $_SESSION['error'] = "Username already exists";
        header('Location: addNewstudents.php');
        exit();
    }
    $check_email = "SELECT * FROM users WHERE email = '$email'";
    $runquery = mysqli_query($connection, $check_email);
    if (mysqli_num_rows($runquery) > 0) {
        $_SESSION['error'] = "Email already exists";
        header('Location: addNewstudents.php');
        exit();
    }
    $query = "INSERT INTO users (name, username, role, email, password) VALUES ('$name', '$username', '$role', '$email', '$password')";
    $result = mysqli_query($connection, $query);

    if ($result) {
        $student_id = mysqli_insert_id($connection);
        $category_id = $_POST['teacher_type'];
        $secondquery = "INSERT INTO student_categories (category_id, user_id) VALUES ('$category_id', '$student_id')";
        $runsecondquery = mysqli_query($connection, $secondquery);

        if ($runsecondquery) {
            $_SESSION['student-added'] = "Student Added Successfully";
            header('Location: allstudents.php');
            exit();
        } else {
            echo "Error: " . mysqli_error($connection);
        }
    } else {
        echo "Error: " . mysqli_error($connection);
    }
}
$query = "SELECT * FROM categories";
$result = mysqli_query($connection, $query);
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <?php
    include('./includes/styleLinks.php')
    ?>
</head>

<body>
    <?php
    include('./includes/header.php')
    ?>
    <?php
    include('./includes/sidebar.php')
    ?>
    <main id="main" class="main">
        <div class="pagetitle">
            <h1>Add Student</h1>
            <nav>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="user.php">Home</a></li>
                    <li class="breadcrumb-item active">Dashboard</li>
                </ol>
            </nav>
        </div>
        <div class="container mt-5">
            <div class="row justify-content-center">
                <div class="col-md-8">
                    <div class="card">
                        <div class="card-body">
                            <h5 class="card-title" style="color: #012970;">Add New Student</h5>
                            <form action="#" method="POST">
                                <div class="mb-3">
                                <?php
                                    if (isset($_SESSION['error'])) {
                                    ?>
                                        <div class="alert alert-success alert-dismissible fade show" role="alert">
                                            <i class="bi bi-check-circle me-1"></i>
                                            <?php echo $_SESSION['error']; ?>
                                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                                        </div>
                                    <?php
                                        unset($_SESSION['error']);
                                    }
                                    ?>
                                    <label for="student" class="form-label" style="color: #012970;">Student Name:</label>
                                    <input type="text" class="form-control" id="student" name="name" required>
                                </div>
                                <div class="mb-3">
                                    <label for="username" class="form-label" style="color: #012970;">username:</label>
                                    <input type="text" class="form-control" id="username" name="username" required>
                                </div>
                                <div class="mb-3">
                                    <label for="email" class="form-label" style="color: #012970;">Email:</label>
                                    <input type="email" class="form-control" id="email" name="email" required>
                                </div>
                                <div class="mb-3">
                                    <label for="password" class="form-label" style="color: #012970;">Password:</label>
                                    <input type="password" class="form-control" id="password" name="password" required>
                                </div>
                                <div class="mb-3">
                                    <label for="testType" class="form-label" style="color: #012970;">Select Category:</label>
                                    <select class="form-select" id="testType" name="teacher_type" required>
                                        <option value="">Select Student Category</option>
                                        <?php
                                        while ($arr = mysqli_fetch_assoc($result)) {
                                            echo "<option value='" . $arr['id'] . "'>" . $arr['name'] . "</option>";
                                        }
                                        ?>
                                    </select>
                                </div>
                                <input name="submit" type="submit" value="Add New" class="btn btn-primary" style="background-color: #012970; border: none;">
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php include('./includes/footer.php'); ?>
</body>

</html>