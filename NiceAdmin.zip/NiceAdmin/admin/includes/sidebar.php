<?php
include('connection.php');
$query = "SELECT * FROM categories";
$result = mysqli_query($connection, $query);
?>
<!-- ======= Sidebar ======= -->
<aside id="sidebar" class="sidebar">
  <ul class="sidebar-nav" id="sidebar-nav">
    <li class="nav-item">
      <a class="nav-link " href="admin.php">
        <i class="bi bi-grid"></i>
        <span>Dashboard</span>
      </a>
    </li><!-- End Dashboard Nav -->
    <li class="nav-item">
      <a class="nav-link collapsed" data-bs-target="#components-nav" data-bs-toggle="collapse" href="#">
        <i class="bi bi-menu-button-wide"></i><span>Categories</span><i class="bi bi-chevron-down ms-auto"></i>
      </a>
      <ul id="components-nav" class="nav-content collapse" data-bs-parent="#sidebar-nav">
        <li>
          <a href="categories.php" class="<?= (basename($_SERVER['PHP_SELF']) == 'categories.php' ? 'active' : '') ?>">
            <i class="bi bi-circle "></i><span>All Categories</span>
          </a>
        </li>
        <li>
          <a href="addCategory.php" class="<?= (basename($_SERVER['PHP_SELF']) == 'addCategory.php' ? 'active' : '') ?>">
            <i class="bi bi-circle"></i><span>Add Category</span>
          </a>
        </li>
      </ul>
    </li><!-- End Components Nav -->
    <li class="nav-item">
      <a class="nav-link collapsed" data-bs-target="#forms-nav" data-bs-toggle="collapse" href="#">
        <i class="bi bi-journal-text"></i><span>Tests</span><i class="bi bi-chevron-down ms-auto"></i>
      </a>
      <ul id="forms-nav" class="nav-content collapse" data-bs-parent="#sidebar-nav">
        <li>
          <a href="allTests.php" class="<?= (basename($_SERVER['PHP_SELF']) == 'allTests.php' ? 'active' : '') ?>">
            <i class="bi bi-circle"></i><span>All Tests</span>
          </a>
        </li>
        <li>
          <a href="addTest.php" class="<?= (basename($_SERVER['PHP_SELF']) == 'addTest.php' ? 'active' : '') ?>">
            <i class="bi bi-circle"></i><span>Add Test</span>
          </a>
        </li>
      </ul>
    </li><!-- End Forms Nav -->

    <li class="nav-item">
      <a class="nav-link collapsed" data-bs-target="#tables-nav" data-bs-toggle="collapse" href="#">
        <i class="bi bi-layout-text-window-reverse"></i><span>Teachers</span><i class="bi bi-chevron-down ms-auto"></i>
      </a>
      <ul id="tables-nav" class="nav-content collapse" data-bs-parent="#sidebar-nav">
        <li>
          <a href="allTeachers.php" class="<?= (basename($_SERVER['PHP_SELF']) == 'allTeachers.php' ? 'active' : '') ?>">
            <i class="bi bi-circle"></i><span>All Teachers</span>
          </a>
        </li>
        <li>
          <a href="addNewTeacher.php" class="<?= (basename($_SERVER['PHP_SELF']) == 'addNewTeacher.php' ? 'active' : '') ?>">
            <i class="bi bi-circle"></i><span>Add Teacher</span>
          </a>
        </li>
      </ul>
    </li><!-- End Tables Nav -->
    <li class="nav-item">
      <a class="nav-link collapsed" data-bs-target="#charts-nav" data-bs-toggle="collapse" href="#">
        <i class="bi bi-bar-chart"></i><span>Students</span><i class="bi bi-chevron-down ms-auto"></i>
      </a>
      <ul id="charts-nav" class="nav-content collapse <?= (basename($_SERVER['PHP_SELF']) == 'allstudents.php' ? 'show' : '') ?>" data-bs-parent="#sidebar-nav">
        <li>
          <a href="allStudents.php" class="<?= (basename($_SERVER['PHP_SELF']) == 'allStudents.php' ? 'active' : '') ?>">
            <i class="bi bi-circle"></i><span>All Students</span>
          </a>
        </li>
        <li>
          <a href="addNewStudents.php" class="<?= (basename($_SERVER['PHP_SELF']) == 'addNewStudents.php' ? 'active' : '') ?>">
            <i class="bi bi-circle"></i><span>Add Student</span>
          </a>
        </li>
        <li>
          <a href="StudentsResult.php" class="<?= (basename($_SERVER['PHP_SELF']) == 'StudentsResult.php' ? 'active' : '') ?>">
            <i class="bi bi-circle"></i><span>Students Result</span>
          </a>
        </li>
      </ul>
    </li><!-- End Charts Nav -->
  </ul>
</aside><!-- End Sidebar-->



<script>
  var element = document.querySelectorAll('.nav-content');
  element.forEach(element => {
    element.addEventListener('click', function(){
      element.classList.toggle('show');
    })
});
</script>