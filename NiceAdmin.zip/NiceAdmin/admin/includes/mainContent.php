<main id="main" class="main">
    <div class="pagetitle">
      <h1>Dashboard</h1>
      <nav>
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="index.html">Home</a></li>
          <li class="breadcrumb-item active">Dashboard</li>
        </ol>
      </nav>
    </div><!-- End Page Title -->
 <section class="section dashboard">
  <div class="row">
    <!-- Test Cards Row -->
    <div class="col-lg-12">
      <div class="row">

        <!-- JavaScript Test Card -->
        <div class="col-xxl-3 col-md-6">
          <a href="Javascript.php" class="card info-card test-card">
            <div class="card-body">
              <h5 class="card-title">JavaScript Test</h5>
              <div class="d-flex align-items-center">
                <div class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                  <i class="bi bi-code-slash"></i>
                </div>
              </div>
            </div>
          </a>
        </div><!-- End JavaScript Test Card -->

        <!-- PHP Test Card -->
        <div class="col-xxl-3 col-md-6">
          <a href="Php.php" class="card info-card test-card">
            <div class="card-body">
              <h5 class="card-title">PHP Test</h5>
              <div class="d-flex align-items-center">
                <div class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                  <i class="bi bi-file-code"></i>
                </div>
              </div>
            </div>
          </a>
        </div><!-- End PHP Test Card -->

        <!-- Python Test Card -->
        <div class="col-xxl-3 col-md-6">
          <a href="Python.php" class="card info-card test-card">
            <div class="card-body">
              <h5 class="card-title">Python Test</h5>
              <div class="d-flex align-items-center">
                <div class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                  <i class="bi bi-code"></i>
                </div>
              </div>
            </div>
          </a>
        </div><!-- End Python Test Card -->

        <!-- C++ Test Card -->
        <div class="col-xxl-3 col-md-6">
          <a href="Cplus.php" class="card info-card test-card">
            <div class="card-body">
              <h5 class="card-title">C++ Test</h5>
              <div class="d-flex align-items-center">
                <div class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                  <i class="bi bi-terminal"></i>
                </div>
              </div>
            </div>
          </a>
        </div><!-- End C++ Test Card -->
      </div>
    </div><!-- End Test Cards Row -->
  </div>
 </section>
</main><!-- End #main -->
