<?php
session_start();
if (!isset($_SESSION['email'])) {
    $_SESSION['message'] = "Please log in first!";
    header("Location: ../index.php");
    exit();
};

include('connection.php');

$query = "SELECT * FROM categories";
$result = mysqli_query($connection, $query);

$test_id = $_GET['id'];
$secondquery = "SELECT * FROM tests WHERE id = $test_id";
$secondresult = mysqli_query($connection, $secondquery);
$test = mysqli_fetch_assoc($secondresult);

if ($test) {
    $category_id = $test['category_id'];
}

$thirdquery = "SELECT * FROM questions WHERE test_id = $test_id";
$questions_result = mysqli_query($connection, $thirdquery);

if (isset($_POST['Update'])) {
    $testname = $_POST['name'];
    $category_id = $_POST['test_type'];
    $query = "UPDATE tests SET category_id = '$category_id', name = '$testname' WHERE id = $test_id";
    mysqli_query($connection, $query);

    $count = 1;
    $questions_result = mysqli_query($connection, $thirdquery);
    while ($row = mysqli_fetch_assoc($questions_result)) {
        $question = $_POST["question_$count"];
        $option1 = $_POST["option1_$count"];
        $option2 = $_POST["option2_$count"];
        $option3 = $_POST["option3_$count"];
        $option4 = $_POST["option4_$count"];
        $correct = $_POST["correct_$count"];

        $update_query = "UPDATE questions SET 
            question = '$question', 
            option1 = '$option1', 
            option2 = '$option2', 
            option3 = '$option3', 
            option4 = '$option4', 
            answer = '$correct' 
            WHERE id = {$row['id']}";

        mysqli_query($connection, $update_query);
        $count++;
    }
    for ($i = $count; $i <= $_POST['count']; $i++) {
        if (isset($_POST["question_$i"])) {
            $question = $_POST["question_$i"];
            $option1 = $_POST["option1_$i"];
            $option2 = $_POST["option2_$i"];
            $option3 = $_POST["option3_$i"];
            $option4 = $_POST["option4_$i"];
            $correct = $_POST["correct_$i"];

            $insert_query = "INSERT INTO questions (test_id, question, option1, option2, option3, option4, answer) VALUES 
                ($test_id, '$question', '$option1', '$option2', '$option3', '$option4', '$correct')";

            mysqli_query($connection, $insert_query);
        }
    }

    $_SESSION['Test-updated'] = "Test updated successfully";
    header("Location: allTests.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <?php include('./includes/styleLinks.php'); ?>
</head>

<body>
    <?php include('./includes/header.php'); ?>
    <?php include('./includes/sidebar.php'); ?>

    <main id="main" class="main">
        <div class="pagetitle">
            <h1>Update Test</h1>
            <nav>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="user.php">Home</a></li>
                    <li class="breadcrumb-item active">Dashboard</li>
                </ol>
            </nav>
        </div>

        <div class="container mt-5">
            <div class="row justify-content-center">
                <div class="col-md-8">
                    <div class="card">
                        <div class="card-body">
                            <h5 class="card-title" style="color: #012970;">Update Test</h5>
                            <form action="#" method="POST">
                                <div class="mb-3">
                                    <label for="question" class="form-label" style="color: #012970;">Test Name:</label>
                                    <input type="text" value="<?php echo $test['name']; ?>" class="form-control" id="question" name="name" required>
                                </div>

                                <div class="mb-3">
                                    <label for="testType" class="form-label" style="color: #012970;">Select Test Type:</label>
                                    <select class="form-select" id="testType" name="test_type" required>
                                        <?php
                                        while ($category = mysqli_fetch_assoc($result)) {
                                            if ($category['id'] == $category_id) {
                                                echo "<option value='" . $category['id'] . "' selected>" . $category['name'] . "</option>";
                                            } else {
                                                echo "<option value='" . $category['id'] . "'>" . $category['name'] . "</option>";
                                            }
                                        }
                                        ?>
                                    </select>
                                </div>

                                <?php
                                $count = 1;
                                while ($row = mysqli_fetch_assoc($questions_result)) {
                                ?>
                                    <hr>
                                    <div class="mb-3">
                                        <label for="question" class="form-label" style="color: #012970;">Question <?php echo $count; ?>:</label>
                                        <input type="text" class="form-control" id="question" name="question_<?php echo $count; ?>"
                                            value="<?php echo $row['question']; ?>" required>
                                    </div>

                                    <div class="mb-3">
                                        <label for="option1" class="form-label" style="color: #012970;">Option 1:</label>
                                        <input type="text" class="form-control" id="option1" name="option1_<?php echo $count; ?>" value="<?php echo $row['option1']; ?>" required>
                                        <div class="form-check mt-2">
                                            <input type="radio" class="form-check-input" id="correct1" name="correct_<?php echo $count; ?>" value="option1" <?php if ($row['answer'] == 'option1') {
                                                                                                                                                                echo "checked";
                                                                                                                                                            } ?>>
                                            <label class="form-check-label" for="correct1" style="color: #012970;">Correct Answer</label>
                                        </div>
                                    </div>

                                    <div class="mb-3">
                                        <label for="option2" class="form-label" style="color: #012970;">Option 2:</label>
                                        <input type="text" class="form-control" id="option2" name="option2_<?php echo $count; ?>" value="<?php echo $row['option2']; ?>" required>
                                        <div class="form-check mt-2">
                                            <input type="radio" class="form-check-input" id="correct2" name="correct_<?php echo $count; ?>" value="option2" <?php if ($row['answer'] == 'option2') {
                                                                                                                                                                echo "checked";
                                                                                                                                                            } ?>>
                                            <label class="form-check-label" for="correct2" style="color: #012970;">Correct Answer</label>
                                        </div>
                                    </div>

                                    <div class="mb-3">
                                        <label for="option3" class="form-label" style="color: #012970;">Option 3:</label>
                                        <input type="text" class="form-control" id="option3" name="option3_<?php echo $count; ?>" value="<?php echo $row['option3']; ?>" required>
                                        <div class="form-check mt-2">
                                            <input type="radio" class="form-check-input" id="correct3" name="correct_<?php echo $count; ?>" value="option3" <?php if ($row['answer'] == 'option3') {
                                                                                                                                                                echo "checked";
                                                                                                                                                            } ?>>
                                            <label class="form-check-label" for="correct3" style="color: #012970;">Correct Answer</label>
                                        </div>
                                    </div>

                                    <div class="mb-3">
                                        <label for="option4" class="form-label" style="color: #012970;">Option 4:</label>
                                        <input type="text" class="form-control" id="option4" name="option4_<?php echo $count; ?>" value="<?php echo $row['option4']; ?>" required>
                                        <div class="form-check mt-2">
                                            <input type="radio" class="form-check-input" id="correct4" name="correct_<?php echo $count; ?>" value="option4" <?php if ($row['answer'] == 'option4') {
                                                                                                                                                                echo "checked";
                                                                                                                                                            } ?>>
                                            <label class="form-check-label" for="correct4" style="color: #012970;">Correct Answer</label>
                                        </div>
                                    </div>

                                <?php
                                    $count++;
                                }
                                ?>

                                <div id="form-container"></div>
                                <input type="hidden" name="count" id="count" value="1">
                                <input name="Update" type="submit" value="Update" class="btn btn-primary" style="background-color: #012970; border: none;">
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php include('./includes/footer.php'); ?>
        <script>
            var count = <?php echo $count - 1; ?>;
        </script>
    </main>
</body>

</html>