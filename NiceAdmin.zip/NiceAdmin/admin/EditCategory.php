<?php
include('connection.php');
session_start();
if (!isset($_SESSION['email'])) {
  $_SESSION['message'] = "Please log in first!";
  header("Location: ../index.php");
  exit();
};
$id = $_GET['id'];
$query = "SELECT * FROM categories WHERE id = '$id'";
$runquery = mysqli_query($connection, $query);
$row = mysqli_fetch_assoc($runquery);

if(isset($_POST['Update'])){
    $new_category = $_POST['new-category'];
    $update_query = "UPDATE categories SET name = '$new_category' WHERE id = '$id'";
    $update_result = mysqli_query($connection, $update_query);

    if($update_result){
        $_SESSION['category-updated'] = "Category updated successfully!";
    } else {
        $_SESSION['category-updated'] = "Failed to update category!";
    }
    header('Location: categories.php');
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <?php
    include('./includes/styleLinks.php')
    ?>
</head>

<body>
    <?php
    include('./includes/header.php')
    ?>
    <?php
    include('./includes/sidebar.php')
    ?>
    <main id="main" class="main">
        <div class="pagetitle">
            <h1>Add Category</h1>
            <nav>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="user.php">Home</a></li>
                    <li class="breadcrumb-item active">Dashboard</li>
                </ol>
            </nav>
        </div>
        <div class="container mt-5">
            <div class="row justify-content-center">
                <div class="col-md-8">
                    <div class="card">
                        <div class="card-body">
                            <h5 class="card-title" style="color: #012970;">Add New Category</h5>
                            <form action="#" method="POST">
                                <div class="mb-3">
                                    <label for="question" class="form-label" style="color: #012970;">Category Name:</label>
                                    <input type="text" value=<?php echo $row['name']?> class="form-control" id="question" name="new-category" required>
                                </div>
                                <input name="Update" type="submit" value="Update" class="btn btn-primary" style="background-color: #012970; border: none;">
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php include('./includes/footer.php'); ?>
</body>

</html>