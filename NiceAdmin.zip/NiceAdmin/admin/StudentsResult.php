<?php
include('connection.php');
session_start();
if (!isset($_SESSION['email'])) {
    $_SESSION['message'] = "Please log in first!";
    header("Location: ../index.php");
    exit();
};
$query = "SELECT * FROM results";
$runquery = mysqli_query($connection, $query);
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <?php include('includes/styleLinks.php'); ?>
</head>

<body>
    <?php include('./includes/sidebar.php'); ?>
    <?php include('./includes/header.php'); ?>

    <main id="main" class="main">
        <div class="pagetitle">
            <h1>Results</h1>
            <nav>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="admin.php">Home</a></li>
                    <li class="breadcrumb-item">Tables</li>
                    <li class="breadcrumb-item active">Data</li>
                </ol>
            </nav>
        </div><!-- End Page Title -->

        <section class="section">
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-body">
                            <h5 class="card-title">Result table</h5>
                            <table class="table datatable">
                                <thead>
                                    <tr>
                                        <th>No.</th>
                                        <th>Name</th>
                                        <th>Test Name</th>
                                        <th>Total Marks</th>
                                        <th>Obtained Marks</th>
                                        <th>Add Subjective Marks</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    $count = 1;
                                    while ($arr = mysqli_fetch_assoc($runquery)) {
                                        $result_id = $arr['id'];
                                        $result_query = "SELECT total_subjective_marks FROM results WHERE id = $result_id";
                                        $run_result = mysqli_query($connection, $result_query);

                                        $user_id = $arr['user_id'];
                                        $query_user = "SELECT name FROM users WHERE id = $user_id";
                                        $run_user = mysqli_query($connection, $query_user);
                                        if ($run_user) {
                                            $user_name = mysqli_fetch_assoc($run_user)['name'];
                                        } else {
                                            $user_name = "Unknown User";
                                        }

                                        $test_id = $arr['test_id'];
                                        $test_query = "SELECT name FROM tests WHERE id = $test_id";
                                        $run_test = mysqli_query($connection, $test_query);
                                        if ($run_test) {
                                            $test_name = mysqli_fetch_assoc($run_test)['name'];
                                        } else {
                                            $test_name = "Unknown Test";
                                        }

                                        echo "<tr>";
                                        echo "<td>" . $count . "</td>";
                                        echo "<td>" . htmlspecialchars($user_name) . "</td>";
                                        echo "<td>" . htmlspecialchars($test_name) . "</td>";
                                        echo "<td>" . (($arr['correct_Answers'] + $arr['wrong_answers']) * 1 + $arr['total_subjective_marks']) . "</td>";
                                        echo "<td>" . ($arr['correct_Answers'] * 1 + $arr['total_obtained_marks']) . "</td>";
                                    ?>
                                        <td>
                                            <?php if ($arr['total_subjective_marks'] > 0) { ?>
                                                <a href="EditSubjective.php?id=<?php echo ($arr['id']) ?>" class="btn btn-primary mx-1"><i class="bi bi-pencil-square"></i> Edit</a>
                                            <?php } else { ?>
                                                <a href="AddSubjective.php?id=<?php echo ($arr['id']) ?>" class="btn btn-warning mx-1"><i class="bi bi-bookmark-plus"></i> Add</a>
                                            <?php } ?>
                                        </td>
                                    <?php
                                        echo "</tr>";
                                        $count++;
                                    }
                                    ?>
                                </tbody>
                            </table>
                            <!-- End Table with stripped rows -->
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </main><!-- End #main -->
    <!-- Footer and Scripts -->
    <?php include('./includes/footer.php'); ?>
</body>

</html>