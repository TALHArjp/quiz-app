<?php
session_start();
if (!isset($_SESSION['email'])) {
    $_SESSION['message'] = "Please log in first!";
    header("Location: ../index.php");
    exit();
}
include('connection.php');

if (isset($_POST['submit'])) {
    $category = $_POST['new-category'];
    $first_query = "SELECT * FROM categories WHERE name = '$category'";
    $run_first_query = mysqli_query($connection, $first_query);
    if (mysqli_num_rows($run_first_query) > 0) {
        $_SESSION['category-exist'] = "Category already exists";
    } else {
        $query = "INSERT INTO categories (name) VALUES ('$category')";
        $runquery = mysqli_query($connection, $query);
        if ($runquery) {
            $_SESSION['category-added'] = "Category added successfully!";
            header('Location: categories.php');
            exit();
        } else {
            $_SESSION['category-error'] = "Failed to add category!";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <?php
    include('./includes/styleLinks.php')
    ?>
</head>

<body>
    <?php
    include('./includes/header.php')
    ?>
    <?php
    include('./includes/sidebar.php')
    ?>
    <main id="main" class="main">
        <div class="pagetitle">
            <h1>Add Category</h1>
            <nav>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="user.php">Home</a></li>
                    <li class="breadcrumb-item active">Dashboard</li>
                </ol>
            </nav>
        </div>
        <div class="container mt-5">
            <div class="row justify-content-center">
                <div class="col-md-8">
                    <div class="card">
                        <div class="card-body">
                            <h5 class="card-title" style="color: #012970;">Add New Category</h5>
                            <?php
                            if (isset($_SESSION['category-exist'])) {
                            ?>
                                <div class="alert alert-success alert-dismissible fade show" role="alert">
                                    <i class="bi bi-check-circle me-1"></i>
                                    <?php echo $_SESSION['category-exist']; ?>
                                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                                </div>
                            <?php
                                unset($_SESSION['category-exist']);
                            }
                            ?>

                            <form action="#" method="POST">
                                <div class="mb-3">
                                    <label for="question" class="form-label" style="color: #012970;">Category Name:</label>
                                    <input type="text" class="form-control" id="question" name="new-category" required>
                                </div>
                                <input name="submit" type="submit" value="Add New" class="btn btn-primary" style="background-color: #012970; border: none;">
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php include('./includes/footer.php'); ?>
</body>

</html>