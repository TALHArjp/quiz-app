<?php
session_start();
if (!isset($_SESSION['email'])) {
  $_SESSION['message'] = "Please log in first!";
  header("Location: ../index.php");
  exit();
};
include('connection.php');
$query = "SELECT * FROM users WHERE role = 'teacher'";
$runquerry = mysqli_query($connection, $query);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <?php
    include('./includes/styleLinks.php');
    ?>
    <!-- =======================================================
  * Template Name: NiceAdmin
  * Template URL: https://bootstrapmade.com/nice-admin-bootstrap-admin-html-template/
  * Updated: Apr 20 2024 with Bootstrap v5.3.3
  * Author: BootstrapMade.com
  * License: https://bootstrapmade.com/license/
  ======================================================== -->
</head>
<body>
    <?php
    include('./includes/sidebar.php')
    ?>
    <?php
    include('./includes/header.php')
    ?>
    <main id="main" class="main">
        <div class="pagetitle">
            <h1>Teacher Table</h1>
            <nav>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="admin.php">Home</a></li>
                    <li class="breadcrumb-item">Tables</li>
                    <li class="breadcrumb-item active">Data</li>
                </ol>
            </nav>
        </div><!-- End Page Title -->
        <section class="section">
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-body">
                            <h5 class="card-title">Teacher's Table</h5>
                            <?php
                            if (isset($_SESSION['Updated-successfully'])) { ?>
                                <div class="alert alert-success alert-dismissible fade show" role="alert">
                                    <?php echo $_SESSION['Updated-successfully']; ?>!
                                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                                </div>
                            <?php
                                unset($_SESSION['Updated-successfully']);
                            }
                            ?>
                            <?php
                            if (isset($_SESSION['Data-Deleted'])) { ?>
                                <div class="alert alert-success alert-dismissible fade show" role="alert">
                                    <?php echo $_SESSION['Data-Deleted']; ?>!
                                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                                </div>
                            <?php
                                unset($_SESSION['Data-Deleted']);
                            }
                            ?>
                             <?php
                            if (isset($_SESSION['teacher-added'])) { ?>
                                <div class="alert alert-success alert-dismissible fade show" role="alert">
                                    <?php echo $_SESSION['teacher-added']; ?>!
                                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                                </div>
                            <?php
                                unset($_SESSION['teacher-added']);
                            }
                            ?>
                            <table class="table datatable">
                                <thead>
                                    <tr>
                                        <th>No.</th>
                                        <th>Name</th>
                                        <th>UserName</th>
                                        <th>Email</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    $count = 1;
                                    while ($arr = mysqli_fetch_assoc($runquerry)) {
                                        echo "<tr>";
                                        echo "<td>" . $count . "</td>";
                                        echo "<td>" . $arr['name'] . "</td>";
                                        echo "<td>" . $arr['username'] . "</td>";
                                        echo "<td>" . $arr['email'] . "</td>";
                                    ?>
                                        <td>
                                            <a href="Editform.php?id=<?php echo ($arr['id']) ?>" class="btn btn-warning mx-1"><i class="ri-edit-line"></i>
                        </div>
                        <a onclick="confirmDelete(<?php echo ($arr['id']) ?>)" class="btn btn-danger mx-1"><i class="bi bi-trash"></i></div>
                    </td>
                <?php
                  echo ("</tr>");
                  $count++;
                }
                ?>
                </tbody>
                </table>
                <!-- End Table with stripped rows -->
                </div>
            </div>
            </div>
            </div>
        </section>
    </main><!-- End #main -->
    <?php include('./includes/footer.php'); ?>
    <script>
        function confirmDelete(event) {
            // event.preventDefault(); 
            const userConfirmed = confirm("Are you sure you want to delete this item?");
            if (userConfirmed) {
                window.location.href = "Delete.php?id=" + encodeURIComponent(event);
            }
        }
    </script>

</body>

</html>