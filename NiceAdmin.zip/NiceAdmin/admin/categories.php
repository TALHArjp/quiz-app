<?php
session_start();
if (!isset($_SESSION['email'])) {
  $_SESSION['message'] = "Please log in first!";
  header("Location: ../index.php");
  exit();
};
include('connection.php');

$query = "SELECT * FROM categories";
$runquerry = mysqli_query($connection, $query);

if(isset($_POST['submit'])){
    header('Location: addcategory.php');
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <?php
    include('./includes/styleLinks.php');
    ?>
</head>
<body>
    <?php
    include('./includes/header.php')
    ?>
    <?php
    include('./includes/sidebar.php')
    ?>
    <main id="main" class="main">
        <div class="pagetitle">
            <h1>Categories Table</h1>
            <nav>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="admin.php">Home</a></li>
                    <li class="breadcrumb-item">Tables</li>
                    <li class="breadcrumb-item active">Data</li>
                </ol>
            </nav>
        </div><!-- End Page Title -->
        <section class="section">
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-body">
                            <h5 class="card-title">All Test Categories</h5>
                            <?php 
                           if(isset($_SESSION['category-added'])) {
                            ?>
                            <div class="alert alert-success alert-dismissible fade show" role="alert">
                                <i class="bi bi-check-circle me-1"></i>
                                <?php echo $_SESSION['category-added']; ?>
                                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                            </div>
                            <?php
                            // Unset the session variable after displaying the alert
                            unset($_SESSION['category-added']);
                        }
                        ?>
                            <?php 
                           if(isset($_SESSION['category-updated'])) {
                            ?>
                            <div class="alert alert-success alert-dismissible fade show" role="alert">
                                <i class="bi bi-check-circle me-1"></i>
                                <?php echo $_SESSION['category-updated']; ?>
                                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                            </div>
                            <?php
                            // Unset the session variable after displaying the alert
                            unset($_SESSION['category-updated']);
                        }
                        ?>
                            <?php 
                           if(isset($_SESSION['Data-Deleted'])) {
                            ?>
                            <div class="alert alert-success alert-dismissible fade show" role="alert">
                                <i class="bi bi-check-circle me-1"></i>
                                <?php echo $_SESSION['Data-Deleted']; ?>
                                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                            </div>
                            <?php
                            // Unset the session variable after displaying the alert
                            unset($_SESSION['Data-Deleted']);
                        }
                        ?>
                            <table class="table datatable">
                                <thead>
                                    <tr>
                                        <th>No.</th>
                                        <th>Name</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    $count = 1 ;
                                    while ($arr = mysqli_fetch_assoc($runquerry)) {
                                        echo "<tr>";
                                        echo "<td>" . $count . "</td>";
                                        echo "<td>" . $arr['name'] . "</td>";
                                    ?>   
                                    <td>
                                        <a href="EditCategory.php?id=<?php echo ($arr['id']) ?>" class="btn btn-warning mx-1"><i class="ri-edit-line"></i></div>
                                        <a onclick="confirmDelete(<?php echo ($arr['id']) ?>)" class="btn btn-danger mx-1"><i class="bi bi-trash"></i></div>
                                    </td>
                                    
                                    <?php
                                        echo ("</tr>");
                                        $count++;
                                    }
                                    ?>
                                </tbody>
                            </table>
                            <!-- End Table with stripped rows -->
                             <form action="#" method="post">
                             <input name="submit" type="submit" value="Add Category" class="btn btn-primary" style="background-color: #012970; border: none;">
                             </form>
                        </div>
                    </div>
                </div>
            </div>
        </section>

    </main><!-- End #main -->

    <?php include('./includes/footer.php'); ?>
    <script>
        function confirmDelete(event) {
            // event.preventDefault(); 
            const userConfirmed = confirm("Are you sure you want to delete this item?");
            if (userConfirmed) {
                window.location.href = "DeleteCategory.php?id=" + encodeURIComponent(event);
            }
        }
    </script>

</body>

</html>