<?php
include('connection.php');
session_start();

if (!isset($_SESSION['email'])) {
    $_SESSION['message'] = "Please log in first!";
    header("Location: ../index.php");
    exit();
}

$user_id = $_SESSION['id'];

$query = "SELECT * FROM results WHERE user_id = $user_id";
$runquery = mysqli_query($connection, $query);
$results = [];

while ($row = mysqli_fetch_assoc($runquery)) {
    $results[] = $row;
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <?php include('includes/styleLinks.php'); ?>
</head>

<body>
    <?php include('./includes/sidebar.php'); ?>
    <?php include('./includes/header.php'); ?>
    <main id="main" class="main">
        <div class="pagetitle">
            <h1>Results</h1>
            <nav>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="index.html">Home</a></li>
                    <li class="breadcrumb-item">Tables</li>
                    <li class="breadcrumb-item active">Data</li>
                </ol>
            </nav>
        </div><!-- End Page Title -->
        <section class="section">
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-body">
                            <h5 class="card-title">Result table</h5>
                            <table class="table datatable">
                                <thead>
                                    <tr>
                                        <th>No.</th>
                                        <th>Name</th>
                                        <th>Total Marks</th>
                                        <th>MCQs Marks</th>
                                        <th>Subjective Marks</th>
                                        <th>Total Obtained Marks</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    $count = 1;
                                    foreach ($results as $result) {
                                        $test_id = $result['test_id'];
                                        $query = "SELECT name FROM tests WHERE id = $test_id";
                                        $runquery = mysqli_query($connection, $query);
                                        $record = mysqli_fetch_assoc($runquery);

                                        echo "<tr>";
                                        echo "<td>" . $count . "</td>";
                                        echo "<td>" . ($record['name']) . "</td>";
                                        echo "<td>" . ((($result['correct_Answers'] + $result['wrong_answers']) * 1) + $result['total_subjective_marks']) . "</td>";
                                        echo "<td>" . ($result['correct_Answers'] * 1) . "</td>";
                                        echo "<td>" . ($result['total_obtained_marks']) . "</td>";
                                        echo "<td>" . (($result['correct_Answers'] * 1) + $result['total_obtained_marks']) . "</td>";
                                        echo "</tr>";
                                        $count++;
                                    }
                                    ?>
                                </tbody>
                            </table>
                            <!-- End Table with stripped rows -->
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </main><!-- End #main -->
    <?php
    require('./includes/footer.php');
    ?>
</body>

</html>