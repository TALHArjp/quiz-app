<?php
session_start();
if (!isset($_SESSION['email'])) {
    $_SESSION['message'] = "Please log in first!";
    header("Location: ../index.php");
    exit();
}
include('connection.php');
$test_id = $_GET['id'];
$_SESSION['test-id'] = $test_id;

$test_check_query = "SELECT test_id FROM results where test_id = '$test_id'";

if (mysqli_num_rows(mysqli_query($connection, $test_check_query)) > 0) {
    $_SESSION['test-check-query'] = "You have already gave this test";
    header('Location: user.php');
    exit();
}

$query = "SELECT * FROM questions WHERE test_id = $test_id";
$runquery = mysqli_query($connection, $query);
$total_questions = mysqli_num_rows($runquery);

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <?php require('./includes/styleLinks.php'); ?>
</head>

<body>
    <?php require('./includes/header.php'); ?>
    <?php require('./includes/sidebar.php'); ?>
    <main id="main" class="main">
        <div class="pagetitle">
            <h1>Test</h1>
            <nav>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="user.php">Home</a></li>
                    <li class="breadcrumb-item active">Questions</li>
                </ol>
            </nav>
        </div><!-- End Page Title -->
        <div class="container mt-5">
            <div class="row justify-content-center">
                <div class="col-md-8">
                    <div class="card">
                        <div class="card-body">
                            <!-- Test Rules Section -->
                            <div id="rules-section" class="text-start">
                                <h3 class="mt-3 mb-4" style="color: #012970;">Test Rules</h3>
                                <p>Please read the following instructions carefully:</p>
                                <ul class="list-unstyled mb-4" style="color: #555;">
                                    <li>1. You will have 60 seconds to answer each question.</li>
                                    <li>2. You can skip a question if you are unsure of the answer.</li>
                                    <li>3. The test will automatically submit after the last question.</li>
                                </ul>
                                <button type="button" id="start-test-btn" class="btn btn-primary" style="background-color: #012970; border: none;">Start Test</button>
                            </div>
                            <!-- Questions Section -->
                            <div id="test-section" style="display:none;">
                                <div id="timer" class="alert text-center w-25 fw-bold mx-auto mt-3" style="background-color: #012970; color: white;">60</div>
                                <form id="question-form" action="result.php" method="POST">
                                    <?php
                                    $count = 1;
                                    while ($row = mysqli_fetch_assoc($runquery)) {
                                    ?>
                                        <div class="question mb-4" id="question_<?php echo $count; ?>" style="display: <?php echo $count === 1 ? 'block' : 'none'; ?>;">
                                            <div>
                                                <label for="question" class="form-label" style="color: #012970; margin-bottom: .5rem;">Question <?php echo $count; ?>: <?php echo $row['question']; ?>?</label>
                                                <input type="hidden" name="<?php echo 'question_' . $count ?>" value="<?php echo $row['id']; ?>">
                                            </div>
                                            <div class="mb-2">
                                                <div class="form-check">
                                                    <input type="radio" style="border: 1px solid black;" class="form-check-input" id="correct1_<?php echo $count; ?>" name="correct_<?php echo $count; ?>" value="option1">
                                                    <label class="form-check-label" for="correct1_<?php echo $count; ?>"><?php echo $row['option1']; ?></label>
                                                </div>
                                            </div>
                                            <div class="mb-2">
                                                <div class="form-check">
                                                    <input type="radio" style="border: 1px solid black;" class="form-check-input" id="correct2_<?php echo $count; ?>" name="correct_<?php echo $count; ?>" value="option2">
                                                    <label class="form-check-label" for="correct2_<?php echo $count; ?>"><?php echo $row['option2']; ?></label>
                                                </div>
                                            </div>
                                            <div class="mb-2">
                                                <div class="form-check">
                                                    <input type="radio" style="border: 1px solid black;" class="form-check-input" id="correct3_<?php echo $count; ?>" name="correct_<?php echo $count; ?>" value="option3">
                                                    <label class="form-check-label" for="correct3_<?php echo $count; ?>"><?php echo $row['option3']; ?></label>
                                                </div>
                                            </div>
                                            <div class="mb-2">
                                                <div class="form-check">
                                                    <input type="radio" style="border: 1px solid black;" class="form-check-input" id="correct4_<?php echo $count; ?>" name="correct_<?php echo $count; ?>" value="option4">
                                                    <label class="form-check-label" for="correct4_<?php echo $count; ?>"><?php echo $row['option4']; ?></label>
                                                </div>
                                            </div>
                                        </div>

                                    <?php
                                        $count++;
                                    }
                                    ?>
                                    <input type="hidden" name="count" id="count" value="<?php echo $count - 1 ?>">
                                    <div class="d-flex gap-2">
                                        <button type="button" class="btn btn-secondary" id="skip-btn" style="background-color: #012970; border: none;">Skip</button>
                                        <button type="button" class="btn btn-primary" id="next-btn" style="background-color: #012970; border: none;">Next</button>
                                    </div>
                                    <input name="submit" type="submit" value="Submit" class="btn btn-primary" style="background-color: #012970; border: none; display:none;" id="submit-btn">
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main><!-- End #main -->
    <?php
    require('./includes/footer.php');
    ?>
    <script>
        document.getElementById('start-test-btn').addEventListener('click', function() {
            document.getElementById('rules-section').style.display = 'none';
            document.getElementById('test-section').style.display = 'block';
            startTimer();
        });
        let timeLeft = 60;
        let timerInterval;

        function startTimer() {
            const timerElement = document.getElementById('timer');
            timerInterval = setInterval(() => {
                if (timeLeft <= 0) {
                    clearInterval(timerInterval);
                    timerElement.innerText = "Time's up!";
                    showNextQuestion();
                } else {
                    timerElement.innerText = timeLeft;
                    timeLeft--;
                }
            }, 1000);
        }
        document.getElementById('next-btn').addEventListener('click', function() {
            showNextQuestion();
        });
        document.getElementById('skip-btn').addEventListener('click', function() {
            showNextQuestion();
        });
        let currentQuestion = 1;
        const totalQuestions = <?php echo $total_questions; ?>;

        function resetTimer() {
            clearInterval(timerInterval);
            timeLeft = 60;
            startTimer();
        }

        function showNextQuestion() {
            document.getElementById('question_' + currentQuestion).style.display = 'none';
            currentQuestion++;
            if (currentQuestion <= totalQuestions) {
                document.getElementById('question_' + currentQuestion).style.display = 'block';
                resetTimer();
            }
            if (currentQuestion >= totalQuestions) {
                document.getElementById('next-btn').style.display = 'none';
                document.getElementById('skip-btn').style.display = 'none';
                document.getElementById('submit-btn').style.display = 'block';
            }

        }
    </script>
    <script>
        let correct;
        for (let i = 1; i <= <?php echo $count; ?>; i++) {
            let answers = {
                ["question" + i]: "<?php if (isset($_POST['submit'])) {
                                        echo $row['question_'];
                                    } ?>" + i,
                ["ans" + i]: "<?php if (isset($_POST['submit'])) {
                                    echo $row['correct_'];
                                } ?>" + i;
            };
        }
        console.log(answers);
        // var objectA = { 
        //             "question-1" :
        //              {
        //                 question :  ,
        //                 ans : 'selected option'
        //              },
        //              "question-2" :
        //              {
        //                 qusiton : 'db qustion' ,
        //                 ans : 'selected option'
        //              }
        //             }
    </script>
</body>

</html>