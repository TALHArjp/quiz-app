<?php
session_start();
if (!isset($_SESSION['email'])) {
  $_SESSION['message'] = "Please log in first!";
  header("Location: ../index.php");
  exit();
}
include('connection.php');
$id = $_SESSION['id'];
$query = "SELECT category_id FROM student_categories WHERE user_id = $id";
$runquery = mysqli_query($connection, $query);
if ($runquery) {
  $result = mysqli_fetch_assoc($runquery);
  $category_id = $result['category_id'];
  $secondquery = "SELECT * FROM tests WHERE category_id = $category_id";
  $runsecondquery = mysqli_query($connection, $secondquery);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <?php
  require('./includes/styleLinks.php');
  ?>
</head>
<body>
  <?php
  require('./includes/header.php');
  require('./includes/sidebar.php');
  ?>
  <main id="main" class="main">
    <div class="pagetitle">
      <h1>Dashboard</h1>
      <nav>
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="user.php">Home</a></li>
          <li class="breadcrumb-item active">Dashboard</li>
        </ol>
      </nav>
    </div><!-- End Page Title -->
    <section class="section dashboard">
      <div class="row">
        <!-- Test Cards Row -->
        <div class="col-lg-12">
          <div class="row">
            <?php
            if (isset($_SESSION['test-check-query'])) {
            ?>
              <div class="alert  alert-success alert-dismissible fade show" role="alert">
                <i class="bi bi-check-circle me-1"></i>
                <?php echo $_SESSION['test-check-query']; ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
              </div>
            <?php
              unset($_SESSION['test-check-query']);
            }
            ?>
            <?php
            if ($runsecondquery) {
              while ($test = mysqli_fetch_assoc($runsecondquery)) {
            ?>
                <div class="col-xxl-3 col-md-6">
                  <a href="testTemplate.php?id=<?php echo $test['id']; ?>" class="card info-card test-card">
                    <div class="card-body">
                      <h5 class="card-title"><?php echo $test['name']; ?></h5>
                    </div>
                  </a>
                </div>
            <?php
              }
            } else {
              echo "No tests available.";
            }
            ?>
          </div>
        </div><!-- End Test Cards Row -->
      </div>
    </section>
  </main><!-- End #main -->
  <?php
  require('./includes/footer.php');
  ?>
</body>
</html>