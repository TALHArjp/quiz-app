<?php
session_start();
if (!isset($_SESSION['email'])) {
    $_SESSION['message'] = "Please log in first!";
    header("Location: ../index.php");
    exit();
};
include('connection.php');

$query = "SELECT * FROM categories";
$runquerry = mysqli_query($connection, $query);

if (isset($_POST['submit'])) {
    header('Location: addcategory.php');
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <?php
    include('./includes/styleLinks.php');
    ?>
</head>

<body>

    <?php
    include('./includes/header.php')
    ?>

    <?php
    include('./includes/sidebar.php')
    ?>

    <main id="main" class="main">

        <div class="pagetitle">
            <h1>Category Table</h1>
            <nav>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="index.html">Home</a></li>
                    <li class="breadcrumb-item">Tables</li>
                    <li class="breadcrumb-item active">Data</li>
                </ol>
            </nav>
        </div><!-- End Page Title -->

        <section class="section">
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-body">
                            <h5 class="card-title">Category Table</h5>
                            <table class="table datatable">
                                <thead>
                                    <tr>
                                        <th>No.</th>
                                        <th>Name</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    $count = 1;
                                    while ($arr = mysqli_fetch_assoc($runquerry)) {
                                        echo "<tr>";
                                        echo "<td>" . $count . "</td>";
                                        echo "<td>" . $arr['name'] . "</td>";
                                    ?>
                                    <?php
                                        echo ("</tr>");
                                        $count++;
                                    }
                                    ?>
                                </tbody>
                            </table>
                            <!-- End Table with stripped rows -->
                        </div>
                    </div>
                </div>
            </div>
        </section>

    </main><!-- End #main -->

    <?php
    require('./includes/footer.php');
    ?>
</body>

</html>