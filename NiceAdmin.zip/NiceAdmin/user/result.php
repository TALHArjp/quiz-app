<?php
include('connection.php');
session_start();
if (!isset($_SESSION['email'])) {
    $_SESSION['message'] = "Please log in first!";
    header("Location: ../index.php");
    exit();
}
$user_id = $_SESSION['id'];
$test_id = $_SESSION['test-id'];
$marks = 0;
$totalmarks = 0;
$correct_answers = 0;
$wrong_aswers = 0;
$i = $_POST['count'];
for ($j = 1; $j <= $i; $j++) {
    $question = $_POST['question_' . $j];
    $answer = $_POST['correct_' . $j];
    $query = "SELECT answer FROM questions WHERE id = $question";
    mysqli_query($connection, $query);
    $result = mysqli_fetch_assoc(mysqli_query($connection, $query));
    if ($result['answer'] == $answer) {
        $marks += 1;
        $correct_answers += 1;
    } else {
        $marks += 0;
        $wrong_aswers += 1;
    }
    $totalmarks += 1;
}

$query = "INSERT INTO results (user_id, test_id, correct_Answers , wrong_answers) VALUES ($user_id, $test_id, $correct_answers ,$wrong_aswers)";
mysqli_query($connection, $query);
if (isset($_SESSION['total-marks'])) {
    $_SESSION['total-marks'] = $total_marks;
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <?php
    include('./includes/styleLinks.php');
    ?>
</head>

<body>
    <?php
    include('./includes/header.php')
    ?>
    <?php
    include('./includes/sidebar.php')
    ?>
    <main id="main" class="main">

        <div class="pagetitle">
            <h1>Result</h1>
            <nav>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="index.html">Home</a></li>
                    <li class="breadcrumb-item">Tables</li>
                    <li class="breadcrumb-item active">Data</li>
                </ol>
            </nav>
        </div><!-- End Page Title -->

        <section class="section">
            <div class="row">
                <div class="col-lg-5">
                    <div class="card">
                        <div class="card-body">
                            <h5 class="card-title">Test Result</h5>
                            <div class="mb-3">
                                <p style="color: #012970;"><?php echo "Total Marks : $totalmarks"; ?></p>
                            </div>
                            <div class="mb-3">
                                <p style="color: #012970;"><?php echo "You have obtained $marks Marks."; ?></p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

    </main><!-- End #main -->

    <?php
    require('./includes/footer.php');
    ?>