<?php
session_start();
if (!isset($_SESSION['email'])) {
    $_SESSION['message'] = "Please log in first!";
    header("Location: ../index.php");
    exit();
}
include('connection.php');
$user_id = $_SESSION['id'];
$query = "SELECT test_id FROM results WHERE user_id = '$user_id'";
$runquery = mysqli_query($connection, $query);

// if ($runquery) {
//     $result = mysqli_fetch_assoc($runquery);
//     $id = $result['test_id'];
//     $query = "SELECT * FROM tests WHERE id = '$id'";
//     $runsecondquery = mysqli_query($connection, $query);
// }
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <?php
    include('includes/styleLinks.php');
    ?>
    <!-- =======================================================
    * Template Name: NiceAdmin
    * Template URL: https://bootstrapmade.com/nice-admin-bootstrap-admin-html-template/
    * Updated: Apr 20 2024 with Bootstrap v5.3.3
    * Author: BootstrapMade.com
    * License: https://bootstrapmade.com/license/
    ======================================================== -->
</head>

<body>
    <?php
    include('includes/header.php')
    ?>
    <?php
    include('includes/sidebar.php')
    ?>
    <main id="main" class="main">
        <div class="pagetitle">
            <h1>All Tests</h1>
            <nav>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="index.html">Home</a></li>
                    <li class="breadcrumb-item">Tables</li>
                    <li class="breadcrumb-item active">Data</li>
                </ol>
            </nav>
        </div><!-- End Page Title -->
        <section class="section">
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-body">
                            <h5 class="card-title">All Tests</h5>
                            <table class="table datatable">
                                <thead>
                                    <tr>
                                        <th>No.</th>
                                        <th>Name</th>
                                        <th>View Details</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    $counter = 1;
                                    while ($arr = mysqli_fetch_assoc($runquery)) { // Fetch each row inside the loop
                                        $test_id = $arr['test_id'];
                                        $query = "SELECT * FROM tests WHERE id = '$test_id'";
                                        $runsecondquery = mysqli_query($connection, $query);
                                        $arr2 = mysqli_fetch_assoc($runsecondquery);
                                        echo "<tr>";
                                        echo "<td>" . $counter . "</td>";
                                        echo "<td>" . $arr2['name'] . "</td>";
                                    ?>
                                        <td>
                                            <a href="resultsTable.php" class="btn btn-warning mx-1">
                                                View Details</a>
                                        <?php
                                        echo "</tr>";
                                        $counter++;
                                    }
                                        ?>
                                </tbody>
                            </table>
                            <!-- End Table with stripped rows -->
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </main><!-- End #main -->
    <?php
    require('./includes/footer.php');
    ?>
</body>

</html>