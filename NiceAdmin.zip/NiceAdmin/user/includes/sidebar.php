<?php
include('connection.php');
$query = "SELECT * FROM categories";
$result = mysqli_query($connection, $query);
?>
<!-- ======= Sidebar ======= -->
<aside id="sidebar" class="sidebar">
  <ul class="sidebar-nav" id="sidebar-nav">
    <li class="nav-item">
      <a class="nav-link " href="user.php">
        <i class="bi bi-grid"></i>
        <span>Dashboard</span>
      </a>
    <li class="nav-item">
      <a class="nav-link <?= (basename($_SERVER['PHP_SELF']) == 'allTests.php' ? 'active' : '') ?>" href="allTests.php">
        <i class="bi bi-journal-text"></i><span>Tests</span>
      </a>
    </li>

    <li class="nav-item">
      <a class="nav-link <?= (basename($_SERVER['PHP_SELF']) == 'resultsTable.php' ? 'active' : '') ?>" href="resultsTable.php">
        <i class="bi bi-journal-text"></i><span>Results</span>
      </a>
    </li>
    </li>
  </ul>
</aside><!-- End Sidebar-->
<script>
  var element = document.querySelectorAll('.nav-content');
  element.forEach(element => {
    element.addEventListener('click', function() {
      element.classList.toggle('show');
    })
  });
</script>